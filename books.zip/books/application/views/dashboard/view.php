
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Lihat Buku</h1>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Id Kategori Buku</th>
              <th>Judul Buku</th>
              <th>Pengarang</th>
              <th>Penerbit</th>
              <th>Tahun Terbit</th>
              <th>Sinopsis</th>
              <th>Cover Buku</th> 
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td><?php echo $idkategori?></td>
              <td><?php echo $judul?></td>
              <td><?php echo $pengarang?></td>
              <td><?php echo $penerbit?></td>
              <td><?php echo $thnterbit?></td>
              <td><?php echo $sinopsis?></td>
              <td><?php echo "<img scr=".base_url()."assets/images/".$img.">"?></td>
            </tr>
            
          </tbody>
        </table>
      </div>
    </main>
  