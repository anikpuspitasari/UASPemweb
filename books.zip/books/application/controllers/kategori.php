
	<?php
class Kategori extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	public function insertKat(){
		$kategori	= $_POST['kategori'];
		// panggil method insertKat() di model 'book_model' untuk menjalankan query insert
		$this->book_model->insertKat($kategori);

		// arahkan ke method 'kategori' di kontroller 'dashboard'
		redirect('dashboard/kategori'); 
		}

	public function delete($idkategori){
		$this->book_model->delKat($idkategori);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}

	// method untuk edit data buku berdasarkan id
	public function edit($idkategori){
		$data['viewBook'] = $this->book_model->showKat($idkategori);

		//ambil session fullname untuk ditampilkan diheader
		$data['fullname'] = $_SESSION['fullname'];
		
		if(empty($data['viewBook'])){
			show_404();
		}
		$data['idkategori'] = $data['viewBook']['idkategori'];
		$data['kategori'] = $data['viewBook']['kategori'];

		// panggil method editBook() di model 'book_model' untuk menjalankan query insert
		$this->load->view('dashboard/header', $data);
		$this->load->view('dashboard/editKat', $data);
		$this->load->view('dashboard/footer');

	}
	// method untuk update kategori buku berdasarkan id
	public function updateKat(){
		

		// baca data dari form insert buku
		$idkategori = $_POST['idkategori'];
		$kategori = $_POST['kategori'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->book_model->updateKat($idkategori, $kategori);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}
	}
	?>
